<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;

class CategoryController2 extends Controller
{

    public function addCategory(Request $request){
        if($request->isMethod('post')){
           $data = $request->all();
           //echo "<pre>"; print_r($data); die;
           
           $category = new Category;
           $category->name = $data['category_name'];
           $category->Parent_id = $data['Parent_id'];
           $category->description = $data['description'];
           $category->url = $data['url'];
           $category->save();
           return redirect('view-categories2')->with('flash_message_success','Category Added Successfully!!!');
        }
        //code for adding sub categories of parent category
        $levels = Category::where(['Parent_id'=>0])->get();
        return view('admin.categories.add_category2')->with(compact('levels'));
    }

    public function viewCategories(){
        //Dynamically Display Categories From Database
        $categories = Category::get();
           return view('admin.categories.view_categories2')->with(compact('categories'));
    }
}