<!--Footer-part-->

<div class="row-fluid">
    <div id="footer" class="span12"> 2020 &copy; Asif Admin </div>
  </div>
  
  <!--end-Footer-part-->