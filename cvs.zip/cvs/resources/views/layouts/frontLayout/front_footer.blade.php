<footer id="footer">
    
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <p align="center">Copyright © 2020 Asif. All rights reserved.</p>
            
            </div>
        </div>
    </div>
    
</footer><!--/Footer-->